import { useEffect, useRef, useCallback } from "react";
import { Room } from "livekit-client";

interface ScreenShareComponentProps {
    room: Room;
    participantIdentity: string;
}

function ScreenShareComponent({ room, participantIdentity }: ScreenShareComponentProps) {
    const hasStartedSharing = useRef(false);

    const startScreenSharing = useCallback(async () => {
        if (participantIdentity.startsWith("USER") && !hasStartedSharing.current) {
            try {
                console.log("화면 공유 요청 시작");
                hasStartedSharing.current = true;
                const tracks = await room.localParticipant.createScreenTracks({
                    preferCurrentTab: true,
                    video: {
                        displaySurface: "monitor"
                    },
                    selfBrowserSurface: "include",
                    surfaceSwitching: "exclude",
                    systemAudio: "include"
                });

                await Promise.all(tracks.map(track => room.localParticipant.publishTrack(track)));
            } catch (error) {
                console.error('Error sharing screen:', error);
                hasStartedSharing.current = false;
            }
        }
    }, [participantIdentity, room]);

    useEffect(() => {
        if (participantIdentity.startsWith("USER")) {
            startScreenSharing();
        }

        return () => {
            // Cleanup logic here
        };
    }, [participantIdentity, startScreenSharing]);

    return null;
}

export default ScreenShareComponent;