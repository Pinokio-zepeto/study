import { useEffect, useRef } from "react";
import { LocalVideoTrack, RemoteVideoTrack } from "livekit-client";
import "./VideoComponent.css";

interface VideoComponentProps {
    track: LocalVideoTrack | RemoteVideoTrack;
    participantIdentity: string;
    local?: boolean;
    showOnlyTeller?: boolean;
}

function VideoComponent({ track, participantIdentity, local = false }: VideoComponentProps) {
    const videoElement = useRef<HTMLVideoElement | null>(null);

    useEffect(() => {
        const attachTrack = async () => {
            if (videoElement.current) {
                await track.attach(videoElement.current);
            }
        };

        attachTrack();
        return () => {
            track.detach();
        };
    }, [track]);

    if (local) {
        return null; // 현재 사용자의 화면은 보이지 않음
    }

    return (
        <div id={`camera-${participantIdentity}`} className="video-container">
            <div className="participant-data">
                <p>{participantIdentity}</p>
            </div>
            <video ref={videoElement} id={track.sid}></video>
        </div>
    );
}

export default VideoComponent;
