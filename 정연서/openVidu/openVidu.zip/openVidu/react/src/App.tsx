import {useEffect, useState} from 'react';

import {
    LocalVideoTrack,
    RemoteParticipant,
    RemoteTrack,
    RemoteTrackPublication,
    Room,
    RoomEvent
} from "livekit-client";
import "./App.css";
import VideoComponent from "./components/VideoComponent";
import AudioComponent from "./components/AudioComponent";
// import ScreenShareComponent from "./components/ScreenShareComponent";

type TrackInfo = {
    trackPublication: RemoteTrackPublication;
    participantIdentity: string;
};

let APPLICATION_SERVER_URL = "";
let LIVEKIT_URL = "";
configureUrls();

function configureUrls() {
    if (!APPLICATION_SERVER_URL) {
        if (window.location.hostname === "localhost") {
            APPLICATION_SERVER_URL = "http://localhost:6080/";
        } else {
            APPLICATION_SERVER_URL = "https://" + window.location.hostname + ":6443/";
        }
    }

    if (!LIVEKIT_URL) {
        if (window.location.hostname === "localhost") {
            LIVEKIT_URL = "ws://localhost:7880/";
        } else {
            LIVEKIT_URL = "wss://" + window.location.hostname + ":7443/";
        }
    }
}

function App() {
    const [room, setRoom] = useState<Room | undefined>(undefined);
    const [localTrack, setLocalTrack] = useState<LocalVideoTrack | undefined>(undefined);
    const [remoteTracks, setRemoteTracks] = useState<TrackInfo[]>([]);
    const [role, setRole] = useState<"TELLER" | "USER">("TELLER");
    const [randomNumber, setRandomNumber] = useState(Math.floor(Math.random() * 100));
    const [roomName, setRoomName] = useState("Test Room");
    const [newRoomName, setNewRoomName] = useState("");
    const [errorMessage, setErrorMessage] = useState<string | null>(null);

    async function joinRoom(roomName: string) {
        const room = new Room();
        setRoom(room);

        room.on(
            RoomEvent.TrackSubscribed,
            (_track: RemoteTrack, publication: RemoteTrackPublication, participant: RemoteParticipant) => {
                setRemoteTracks((prev) => [
                    ...prev,
                    { trackPublication: publication, participantIdentity: participant.identity }
                ]);
            }
        );

        room.on(RoomEvent.TrackUnsubscribed, (_track: RemoteTrack, publication: RemoteTrackPublication) => {
            setRemoteTracks((prev) => prev.filter((track) => track.trackPublication.trackSid !== publication.trackSid));
        });

        try {
            const token = await getToken(roomName, `${role}_${randomNumber}`);

            await room.connect(LIVEKIT_URL, token);

            // 카메라만 연결 - 마이크는 추후 제어
            await room.localParticipant.setCameraEnabled(true);
            setLocalTrack(room.localParticipant.videoTrackPublications.values().next().value.videoTrack);

        } catch (error) {
            console.log("There was an error connecting to the room:", (error as Error).message);
            setErrorMessage((error as Error).message);
            await leaveRoom();
        }
    }

    async function leaveRoom() {
        await room?.disconnect();

        setRoom(undefined);
        setLocalTrack(undefined);
        setRemoteTracks([]);
    }

    async function changeRoom() {
        console.log("Changing room from", roomName, "to", newRoomName);
        if (newRoomName && newRoomName !== roomName) {
            console.log("Leaving current room:", roomName);
            await leaveRoom();
            console.log("Setting new room name:", newRoomName);
            setRoomName(newRoomName);
            setNewRoomName("");
            console.log("Joining new room:", newRoomName);
            await joinRoom(newRoomName);
        }
    }

    async function getToken(roomName: string, participantName: string) {
        try {
            const response = await fetch(APPLICATION_SERVER_URL + "token", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    roomName: roomName,
                    participantName: participantName
                })
            });

            if (!response.ok) {
                const error = await response.json();
                setErrorMessage(error.errorMessage);
                throw new Error(`Failed to get token: ${error.errorMessage}`);
            }

            const data = await response.json();
            setErrorMessage(null);  // 성공 시 에러 메시지 초기화
            return data.token;
        } catch (error) {
            console.error("Error getting token:", error);
            setErrorMessage((error as Error).message);
            throw error;
        }
    }

    async function sendHelpRequest() {
        if (room) {
            const message = `${room.localParticipant.identity}에서 도움 요청!`;
            const encoder = new TextEncoder();
            const data = encoder.encode(message);

            await room.localParticipant.publishData(data);
        }
    }

    useEffect(() => {
        if (room) {
            const handleDataReceived = (payload: Uint8Array, participant: RemoteParticipant) => {
                const message = new TextDecoder().decode(payload);
                console.log("메시지 수신! 현 유저: " + role);
                console.log("수신된 메시지:", message);
                console.log("메시지를 보낸 참가자:", participant.identity);

                if (role == "TELLER") {
                    alert(message);
                }
            };

            room.on(RoomEvent.DataReceived, handleDataReceived);

            // Clean up the event handler when the component is unmounted or room changes
            return () => {
                room.off(RoomEvent.DataReceived, handleDataReceived);
            };
        }
    }, [room, role]);

    return (
        <>
            {!room ? (
                <div id="join">
                    <div id="join-dialog">
                        <h2>Join a Video Room</h2>
                        {errorMessage && (
                            <div className="error-message" style={{color: 'red', marginBottom: '10px'}}>
                                Error: {errorMessage}
                            </div>
                        )}
                        <form
                            onSubmit={(e) => {
                                joinRoom(roomName);
                                e.preventDefault();
                            }}
                        >
                            <div>
                                <label htmlFor="participant-role">Role</label>
                                <select
                                    id="participant-role"
                                    className="form-control"
                                    value={role}
                                    onChange={(e) => {
                                        setRole(e.target.value as "TELLER" | "USER");
                                        setRandomNumber(Math.floor(Math.random() * 100));
                                    }}
                                    required
                                >
                                    <option value="TELLER">TELLER</option>
                                    <option value="USER">USER</option>
                                </select>
                            </div>
                            <div>
                                <label htmlFor="room-name">Room</label>
                                <input
                                    id="room-name"
                                    className="form-control"
                                    type="text"
                                    value={roomName}
                                    onChange={(e) => setRoomName(e.target.value)}
                                    required
                                />
                            </div>
                            <button
                                className="btn btn-lg btn-success"
                                type="submit"
                                disabled={!roomName}
                            >
                                Join!
                            </button>
                        </form>
                    </div>
                </div>
            ) : (
                <div id="room">
                    <div id="room-header">
                        <h2 id="room-title">{roomName}</h2>
                        <input
                            className="form-control"
                            type="text"
                            value={newRoomName}
                            onChange={(e) => setNewRoomName(e.target.value)}
                            placeholder="Enter new room name"
                        />
                        {/*<button*/}
                        {/*    className="btn btn-primary"*/}
                        {/*    onClick={changeRoom}*/}
                        {/*    disabled={!newRoomName || newRoomName === roomName}*/}
                        {/*>*/}
                        {/*    Change Room*/}
                        {/*</button>*/}
                        <button className="btn btn-danger" id="leave-room-button" onClick={leaveRoom}>
                            Leave Room
                        </button>
                        <button className="btn btn-warning" id="help-button" onClick={sendHelpRequest}>
                            Help
                        </button>
                    </div>
                    <div id="layout-container">
                        {localTrack && (
                            <>
                                <VideoComponent track={localTrack} participantIdentity={`${role}_${randomNumber}`} local={true}/>
                                {/*<ScreenShareComponent room={room} participantIdentity={`${role}_${randomNumber}`} />*/}
                            </>
                        )}
                        {remoteTracks
                            .filter(remoteTrack => role.startsWith("TELLER") || remoteTrack.participantIdentity.startsWith("TELLER"))
                            .map((remoteTrack) =>
                                remoteTrack.trackPublication.kind === "video" ? (
                                    <VideoComponent
                                        key={remoteTrack.trackPublication.trackSid}
                                        track={remoteTrack.trackPublication.videoTrack!}
                                        participantIdentity={remoteTrack.participantIdentity}
                                    />
                                ) : (
                                    <AudioComponent
                                        key={remoteTrack.trackPublication.trackSid}
                                        track={remoteTrack.trackPublication.audioTrack!}
                                    />
                                )
                            )
                        }
                    </div>
                </div>
            )}
        </>
    );
}

export default App;
